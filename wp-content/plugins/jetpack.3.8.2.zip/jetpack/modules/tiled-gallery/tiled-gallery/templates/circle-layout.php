<?php
$this->template( 'square-layout', $context );

